# this will open the file
# file = open('file.txt', encoding='utf8')

import requests
import time
import os
import concurrent.futures

files_list = ['small_file_300.txt',
              'small_file_600.txt'
              ]

t1 = time.time()


def Inverted_index_search(file_list):
    file = open(file_list, encoding='ISO-8859-1')

    read = file.read()
    file.seek(0)
    read

    # to obtain the
    # number of lines
    # in file
    line = 1
    for word in read:
        if word == '\n':
            line += 1
    print("Number of lines in file is: ", line)

    # create a list to
    # store each line as
    # an element of list
    array = []
    for i in range(line):
        array.append(file.readline())

    # return array

    punc = '''!()-[]{};:'"\, <>./?@#$%^&*_~'''
    for ele in read:
        if ele in punc:
            read = read.replace(ele, " ")

    # read

    # to maintain uniformity
    read = read.lower()
    # read

    from nltk.tokenize import word_tokenize
    import nltk
    from nltk.corpus import stopwords
    # nltk.download('stopwords')

    for i in range(1):
        # this will convert
        # the word into tokens
        text_tokens = word_tokenize(read)

    tokens_without_sw = [
        word for word in text_tokens if not word in stopwords.words()]

    print(tokens_without_sw)

    dict = {}

    for i in range(line):
        check = array[i].lower()
        for item in tokens_without_sw:

            if item in check:
                if item not in dict:
                    dict[item] = []

                if item in dict:
                    dict[item].append(i + 1)

    dict
    print("Item found in lines : %s  \n " % dict.get('vinci'))
    print("in the file : ", file.name)

    # return array , read


# #array

# for file in files_list:
# 	Inverted_index_search(file)


# t2 = time.time()
# print(f'Single Process Code Took :{t2-t1} seconds')
# print('*'*50)

if __name__ == '__main__':
    t1 = time.time()

    # t3 = time.time()
    # print("Downloading images with Multiprocess")

    # # def download_image(img_url):
    # # 	img_bytes = requests.get(img_url).content
    # # 	print(f"[Process ID]:{os.getpid()} Downloading..")

    with concurrent.futures.ProcessPoolExecutor(4) as exe:
        exe.map(Inverted_index_search, files_list)

    t2 = time.time()

    print(f'Multiprocess Code Took:{t2 - t1} seconds')

# c=Inverted_index_search()
# c

