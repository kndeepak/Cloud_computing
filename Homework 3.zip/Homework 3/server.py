import requests
import time
import os
import concurrent.futures
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template('web.html')

@app.route('/', methods=['POST'])
def my_form_post():


    search = request.form['text']



    files_list=['small_file_300.txt',
               'small_file_600.txt',
               'small_file_900.txt,
               'small_file_1200.txt,
                  ]


    def Inverted_index_search(file_list):    
        file = open(file_list,encoding='ISO-8859-1')

        read = file.read()
        file.seek(0)
        #read

        # to obtain the
        # number of lines
        # in file
        line = 1
        for word in read:
            if word == '\n':
                line += 1
        #print("Number of lines in file is: ", line)

        # create a list to
        # store each line as
        # an element of list
        array = []
        for i in range(line):
            array.append(file.readline())
            
        #return array 

        punc = '''!()-[]{};:'"\, <>./?@#$%^&*_~'''
        for ele in read:
            if ele in punc:
                read = read.replace(ele, " ")

        #read

        # to maintain uniformity
        read=read.lower()                   
        #read
        
        from nltk.tokenize import word_tokenize
        import nltk
        from nltk.corpus import stopwords
        #nltk.download('stopwords')

        for i in range(1):
            # this will convert
            # the word into tokens
            text_tokens = word_tokenize(read)

        tokens_without_sw = [
            word for word in text_tokens if not word in stopwords.words()]

        #print(tokens_without_sw)
        
        my_dict = {}

        for i in range(line):
            check = array[i].lower()
            for item in tokens_without_sw:

                if item in check:
                    if item not in my_dict:
                        my_dict[item] = []

                    if item in my_dict:
                        my_dict[item].append(i+1)
        return my_dict

        def reducer(intermerdiate_list, search):
            lst=intermerdiate_list
            result=intermerdiate_list.get(search)
            
            return result 


        #dict
        #print ("Item found in lines : %s  \n " %  my_dict.get('vinci') )
        #print("in the file : ",file.name)



    for file in files_list:
        Inverted_index_search(file)
        print ("Item found in lines : %s  \n " %  my_dict.get('vinci') )

    if __name__ == '__main__':

          
            # to invoke map process via multi processing 
          result =[]
          with concurrent.futures.ProcessPoolExecutor(8) as exe:
            result= exe.map(Inverted_index_search, files_list)


            intermerdiates_list=result
            #to invoke reduce fuction via multiprocessing 
          with concurrent.futures.ProcessPoolExecutor(8) as exe:
            result1= exe.map(reducer, intermerdiate_list)







        print ("Item found in lines : %s  \n " %  my_dict.get('vinci') )
        print("in the file : ",result[i])








        
        result=search



        return search

if __name__ == '__main__':
    app.run()