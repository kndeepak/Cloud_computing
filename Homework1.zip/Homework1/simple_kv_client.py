#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import socket

ClientSocket = socket.socket()
host = '127.0.0.1'
port = 9889

print('Waiting for connection')
try:
    ClientSocket.connect((host, port))
except socket.error as e:
    print(str(e))

Response = ClientSocket.recv(2048)
while True:
    Input = input('Enter command for KEY-VALUE store: \nHelp: \n get <key> \n set <key> <value> ')
    ClientSocket.send(str.encode(Input))
    Response = ClientSocket.recv(2048)
    print(Response.decode('utf-8'))

ClientSocket.close()


# In[ ]:




