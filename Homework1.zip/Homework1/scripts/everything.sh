


gcloud compute scp simple_kv_server-2.py data.pkl server:/home/deepak
gcloud compute ssh root@server: <"cd /home/deepak"
#cd /home/deepak/
# <"python3 /home/deepak/simple_kv_server-2.py"
#'bash -s' < script.sh
#gcloud compute ssh -t dekasi@server "cd /home/deepak; exec \$SHELL -l"
#cd /home/deepak/
#sudo su #"cd /home/deepak/" 
#cd /home/deepak
#python3 /home/deepak/simple_kv_server-2.py
sh s.sh &
sh c.sh 


