
gcloud compute scp simple_kv_server-2.py data.pkl server:/home/deepak
gcloud compute ssh root@server: 


sudo su 
cd /home/deepak
python3 simple_kv_server-2.py


exit 
rm data.pkl
exit
gcloud compute instances stop server