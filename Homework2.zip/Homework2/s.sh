
gcloud compute scp simple_kv_server-2.py data.pkl server:~
gcloud compute ssh root@server


#sudo su 
cd /home/deepak
python3 simple_kv_server-2.py


 
rm data.pkl
rm simple_kv_server-2.py
exit
gcloud compute instances stop server