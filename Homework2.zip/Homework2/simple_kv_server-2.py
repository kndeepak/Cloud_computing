#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import socket
import os
from _thread import *
import pickle
import warnings
warnings.filterwarnings("ignore")


HEADERSIZE = 10

ServerSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
ServerSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

host = '0.0.0.0'
port = 80
ThreadCount = 0


try:
    ServerSocket.bind((host, port))
except socket.error as e:
    print(str(e))

print('Waitiing for a Connection..')
ServerSocket.listen(5)


def threaded_client(connection):
    connection.send(str.encode('Welcome to the Server n'))
    while True:


            import pickle
            a_file = open("data.pkl", "rb")
            output = pickle.load(a_file)
            print(output)
            a_file.close()
            
            data = connection.recv(2048)
            print("data without decode", data)
            data_decode=data.decode('utf-8') #input key value 

            res = data_decode.split()
            print("result is",res)


  
            if res[0]=='set':
                

                    update_element =([(res[1], res[2])])

                    a_file = open("data.pkl", "rb")
                    dict_file = pickle.load(a_file)
                    print(dict_file)

                    dict_file.update(update_element)

                   # print(dict_file)

                    a_file = open("data.pkl", "wb")
                    pickle.dump(dict_file, a_file)
                    a_file.close()

                    a_file = open("data.pkl", "rb")
                    dict_file = pickle.load(a_file)
                    print(dict_file)
                    a_file.close()
                    
                    print('STORED') 
                    reply = 'STORED\r\n'
                    #STORED\r\n", or "NOT-STORED\r\n".

            elif res[0]=='get':



                    import pickle

                    get_element =res[1]
                    #function to return key for any value
                    def get_key(val):

                        a_file = open("data.pkl", "rb")
                        dict_file = pickle.load(a_file)
                        print(dict_file)
                        
                

                        for key, value in dict_file.items():

                             if val == key :
                                    return value
                        return "key doesn't exist"

                    def change_value(Inputkey):
                        if Inputkey.isnumeric()==True:

                            return int(Inputkey)
                        else:
                            return str(Inputkey)




                    
                    val=change_value(get_element)
                    #print(val)
                    s=get_key(val)
                    #print(s)
                    reply =  s + '\n  END\r\n'
                             

            else :

                print('invalid operation')
            if not data:
                break
            connection.sendall(str.encode(reply))
    connection.close()

while True:
    Client, address = ServerSocket.accept()
    print('Connected to: ' + address[0] + ':' + str(address[1]))
    start_new_thread(threaded_client, (Client, ))
    ThreadCount += 1
    print('Thread Number: ' + str(ThreadCount))
    

    
    
ServerSocket.close()


# In[ ]:




