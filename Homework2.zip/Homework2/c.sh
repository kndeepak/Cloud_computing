
gcloud compute scp simple_kv_client.py simple_kv_client_test-2.py client:~
gcloud compute ssh root@client

#sudo su 
cd /home/deepak
python3 simple_kv_client_test-2.py
rm simple_kv_client_test-2.py
exit

gcloud compute instances stop client
