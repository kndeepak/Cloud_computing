import socket
import time

ClientSocket = socket.socket()

host = '34.121.64.249'
port = 80

print('Waiting for connection')
#while True:   
try:
    ClientSocket.connect((host, port))
except socket.error as e:
    print(str(e))

Response = ClientSocket.recv(2048)
while True:
    #Input = input('Enter command for KEY-VALUE store: \nHelp: \n get <key> \n set <key> <value> ')
    Input = str("set 2 two")
    tic = time.perf_counter()
    ClientSocket.send(str.encode(Input))
    Response = ClientSocket.recv(2048)
    toc = time.perf_counter()
    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")

    #break 

    Input = str("set 3 three")
    tic = time.perf_counter()
    ClientSocket.send(str.encode(Input))
    Response = ClientSocket.recv(2048)
    toc = time.perf_counter()
    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")

    break
    

ClientSocket.close()

pass

ClientSocket1 = socket.socket()
# host = '127.0.0.1'
# port = 9889

try:
    ClientSocket1.connect((host, port))
except socket.error as e:
    print(str(e))

Response = ClientSocket1.recv(2048)
while True:
    #Input = input('Enter command for KEY-VALUE store: \nHelp: \n get <key> \n set <key> <value> ')
    Input = str("get 2 ")
    tic = time.perf_counter()
    ClientSocket1.send(str.encode(Input))
    Response = ClientSocket1.recv(2048)
    toc = time.perf_counter()

    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")
    
    

    #break 

    Input = str("get new5 ")
    tic = time.perf_counter()
    ClientSocket1.send(str.encode(Input))
    Response = ClientSocket1.recv(2048)
    toc = time.perf_counter()
    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")

    break
    

pass

ClientSocket3 = socket.socket()
# host = '127.0.0.1'
# port = 9889

try:
    ClientSocket3.connect((host, port))
except socket.error as e:
    print(str(e))

Response = ClientSocket3.recv(2048)
while True:
    #Input = input('Enter command for KEY-VALUE store: \nHelp: \n get <key> \n set <key> <value> ')
    Input = str("get 2 ")
    tic = time.perf_counter()
    ClientSocket3.send(str.encode(Input))
    Response = ClientSocket3.recv(2048)
    toc = time.perf_counter()

    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")
    
    

    #break 

    Input = str("get new5 ")
    tic = time.perf_counter()
    ClientSocket3.send(str.encode(Input))
    Response = ClientSocket3.recv(2048)
    toc = time.perf_counter()
    print(Response.decode('utf-8'))
    print(f"server responded in {toc - tic:0.8f} seconds")

    break
ClientSocket.close()








