sh s.sh &
sh c.sh 


